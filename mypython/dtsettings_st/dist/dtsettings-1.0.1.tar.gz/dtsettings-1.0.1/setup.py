from distutils.core import setup

setup(
    name         ='dtsettings',
    version      ='1.0.1',
    py_modules   =['dtsettings'],
    author       ='long.ao',
    author_email ='islong.ao@outlook.com',
    description  ='This is my own data-analysis work-box.',
    )
