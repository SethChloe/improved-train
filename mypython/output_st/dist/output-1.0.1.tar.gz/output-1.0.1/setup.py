from distutils.core import setup

setup(
    name         ='output',
    version      ='1.0.1',
    py_modules   =['output'],
    author       ='long.ao',
    author_email ='islong.ao@outlook.com',
    description  ='A package which can beautify matrix output or save a matrix.',
    )
